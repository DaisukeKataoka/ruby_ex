message = "Hello"
puts message
message = message + ", world"
puts message
a = 100 + 20
puts a
