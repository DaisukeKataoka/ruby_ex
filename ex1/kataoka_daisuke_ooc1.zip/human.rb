class Human
  def initialize(name)
    @name = name
  end

  def profile
    puts "My Name is #{@name}"
  end
end
