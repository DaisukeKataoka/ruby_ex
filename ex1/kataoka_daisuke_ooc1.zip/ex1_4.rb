require './human'

s = "This is a message"
puts s.length
puts s.object_id

puts Human.class
puts s.class
